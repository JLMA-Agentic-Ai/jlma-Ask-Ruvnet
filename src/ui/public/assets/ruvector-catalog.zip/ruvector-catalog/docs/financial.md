# Financial Trading — Deep Dive

## Crates
- **neural-trader-core**: Canonical market event types (MarketEvent), graph schema, ingest traits. Fields: event_id, ts_exchange_ns, ts_ingest_ns, venue_id, symbol_id, event_type, side, price_fp (fixed-point), qty_fp, order_id_hash, participant_id_hash
- **neural-trader-coherence**: MinCut coherence gate + CUSUM drift detection + proof-gated mutation protocol. CoherenceDecision: allow_retrieve, allow_write, allow_learn, allow_act, mincut_value, drift_score, cusum_score. Every memory write, model update, retrieval, and actuation must pass through this gate
- **neural-trader-replay**: Witnessable replay segments with RVF serialization, audit receipt logging. ReplaySegment: events, embeddings, labels, coherence stats. Sealed and signed
- **neural-trader-wasm**: Browser bindings

## Architecture (ADR-084)
Market events → graph schema → embeddings → coherence gate → actions. Every decision is witnessed and auditable.

## Examples
examples/neural-trader, examples/apify/neural-trader-system

*Source: ruvector/crates/neural-trader-core/src/lib.rs*
