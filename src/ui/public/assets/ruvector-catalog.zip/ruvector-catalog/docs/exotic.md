# Exotic & Specialized — Deep Dive

## ruvector-exotic-wasm
- **Neural Autonomous Organizations (NAO)**: Decentralized governance for AI collectives. Stake-weighted quadratic voting, oscillatory synchronization, quorum consensus
- **Morphogenetic Networks**: Developmental biology-inspired coordination. Growth patterns for distributed systems
- **Time Crystals**: Periodic state without energy input. Stability patterns for distributed computation

## thermorust
Thermodynamic neural motifs. Energy-driven state transitions with Landauer dissipation:
- Modules: state, energy (Ising, SoftSpin, Couplings), dynamics (Metropolis-Hastings, Langevin, annealers), noise (Langevin, Poisson spike), metrics (magnetisation, overlap, entropy, free energy, Trace), motifs (ring, fully-connected, Hopfield, soft-spin)

## ruvector-crv
Coordinate Remote Viewing protocol mapped to RuVector: Stage I (ideograms) → Poincaré embeddings, Stage II (sensory) → multi-head attention, Stage III (dimensional) → GNN topology, Stage IV (emotional) → SNN temporal, Stage V (interrogation) → differentiable search, Stage VI (3D model) → MinCut partitioning

## ruvector-dither
Pre-quantization dithering for 3/5/7-bit inference: GoldenRatioDither (best 1-D equidistribution), PiDither (table of π bytes, period=256). No RNG, deterministic, reproducible across WASM/x86/ARM

## ruvector-sparse-inference + wasm
PowerInfer-style activation locality. P·Q low-rank neuron prediction. Hot/cold neuron caching. π integration (calibration, drift detection, angular embeddings, chaos seeding). Precision lanes: 3/5/7-bit with graduation policies. Target: 2.5-10x speedup

## ruvector-temporal-tensor + wasm
Time-series tensor compression with TurboQuant. Tiered quantization over time

## ruvector-cognitive-container
Sealed WASM container with tamper-evident witness chains. Epoch budgeting. Components: graph ingest, min-cut, spectral analysis, evidence accumulation

## ruvector-domain-expansion + wasm
Cross-domain transfer learning. Meta Thompson Sampling. Rust synthesis + planning + tool orchestration domains. Population-based policy search

## ruvector-profiler
Memory (MemoryTracker, MemorySnapshot), power (PowerTracker, MockPowerSource, EnergyResult), latency (LatencyRecord, LatencyStats) with CSV emitters and config hashing

## Specialized Examples
- examples/dna (rvDNA): 20-SNP biomarker scoring, 23andMe, CYP2D6/CYP2C19 pharmacogenomics
- examples/scipix: OCR for scientific documents, LaTeX/MathML extraction, ONNX GPU
- examples/dragnes: DrAgnes dermatology intelligence platform
- examples/vibecast-7sense: Bioacoustic intelligence platform
- examples/exo-ai-2025: Advanced cognitive substrate
- examples/ultra-low-latency-sim: Quadrillion simulations/sec with SIMD
- examples/verified-applications: 10 apps of formal verification

*Source: ruvector/crates/thermorust/src/lib.rs, ruvector/crates/ruvector-crv/src/lib.rs*
