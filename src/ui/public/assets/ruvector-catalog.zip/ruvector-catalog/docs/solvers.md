# Sublinear Solvers — Deep Dive

## Crates
- **ruvector-solver** + wasm + node: 8 algorithms + auto-router, 18 source files

## Algorithms
| Algorithm | Complexity | Use When |
|-----------|-----------|----------|
| Neumann Series | O(k * nnz) | Diag-dominant, spectral radius < 1 |
| Conjugate Gradient | O(√κ * log(1/ε)) | Symmetric positive-definite, well-conditioned |
| Forward Push | O(1/ε) | Single-source PageRank, trust propagation |
| Backward Push | O(1/ε) | Reverse PageRank, backward reachability |
| Hybrid Random Walk | Sublinear in graph size | Large-scale pairwise PageRank |
| BMSSP Multigrid | O(nnz * log n) | Laplacian/SPD, multi-scale problems |
| TRUE Solver | O(log n) | Batch via JL projection + sparsification |
| Auto-Router | Varies | Don't know which to use — picks automatically |

## Additional Named Algorithms
Jacobi iteration (diagonal-based fallback), Gauss-Seidel (forward sweep, BMSSP smoother), PCG32 PRNG (deterministic JL projection), Johnson-Lindenstrauss projection (dimensionality reduction), Welford's algorithm (online mean/variance), power iteration (spectral radius estimation), dense Gaussian elimination (last-resort with partial pivoting)

## Auto-Router Decision Logic
9 routing rules based on matrix properties: symmetry, diagonal dominance, spectral radius, condition number, sparsity. Fallback chain: primary → CG → Dense

## Key Constants
6 thresholds control routing behavior

## Research
docs/research/sublinear-time-solver (34 docs): Executive summary, algorithm analysis, MCP integration, AGI optimization, DNA convergence, quantum convergence

## Examples
examples/subpolynomial-time, examples/train-discoveries

*Source: ruvector/crates/ruvector-solver/src/lib.rs*
