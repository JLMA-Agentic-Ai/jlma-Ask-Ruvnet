# Robotics — Deep Dive

## Crates
- **agentic-robotics-core**: Core types and traits for robotics
- **agentic-robotics-rt**: Real-time runtime (dual-runtime architecture)
- **agentic-robotics-embedded**: Embedded systems (no_std, RTIC+Embassy frameworks)
- **agentic-robotics-mcp**: MCP protocol integration for robotics
- **agentic-robotics-node**: Node.js bindings
- **agentic-robotics-benchmarks**: Performance benchmarking suite
- **ruvector-robotics**: Cognitive robotics platform. Modules: bridge/ (ROS3+Zenoh types), perception/ (sensor pipeline), cognitive/ (cognitive architecture), mcp/ (MCP tools)

## Research
docs/research/agentic-robotics (5 docs): SOTA integration analysis with ruvector

## Examples
examples/robotics

*Source: ruvector/crates/ruvector-robotics/src/lib.rs, ruvector/crates/agentic-robotics-core/src/lib.rs*
