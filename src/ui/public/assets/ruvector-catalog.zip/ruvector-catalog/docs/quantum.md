# Quantum Computing — Deep Dive

## Crates
- **ruQu**: Classical nervous system for quantum machines. 256-tile WASM fabric, syndrome processing, coherence gate
- **ruqu-core**: Full state-vector quantum simulation. Gates, measurement, noise channels, SIMD acceleration. Up to 25 qubits in browser
- **ruqu-algorithms**: VQE (molecular chemistry, H2 Hamiltonian), Grover's search (quadratic speedup), QAOA (MaxCut optimization), Surface Code (distance-3 error correction, stabilizer measurement, syndrome decoding)
- **ruqu-exotic**: 8 quantum-classical hybrid algorithms:
  - **quantum_decay**: Embeddings decohere via T1 (amplitude damping) and T2 (dephasing) instead of TTL deletion
  - **interference_search**: Concepts interfere during retrieval, resolving polysemy via constructive/destructive interference
  - **quantum_collapse**: Nondeterministic top-k with Grover-like amplitude bias. Oracle biases toward high-similarity
  - **reasoning_qec**: Surface-code error correction on reasoning traces
  - **reversible_memory**: Time-reversible state for counterfactual debugging ("what if this observation was missing?")
  - **swarm_interference**: Agents interfere instead of voting for consensus
  - **syndrome_diagnosis**: QEC syndrome extraction for system monitoring
  - **reality_check**: Browser-native quantum verification circuits
- **ruqu-wasm**: All of the above in browser

## QuDAG Crypto (inside ruvector-dag)
ML-DSA-65 (Dilithium3), ML-KEM-768 (Kyber768), differential privacy, zeroize keystore

## Research
docs/research/quantum-crypto (3 docs): Blockchain forensics beyond SOTA

*Source: ruvector/crates/ruqu-core/src/lib.rs*
