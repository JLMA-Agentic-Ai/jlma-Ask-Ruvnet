# Storage & Database — Deep Dive

## Crates
- **ruvector-postgres**: PostgreSQL extension — 230+ SQL functions, pgvector drop-in replacement. Modules: attention/, dag/, distance/, domain_expansion/, embeddings/, gated_transformer/, gnn/, graph/ (cypher+sparql), healing/, hybrid/, hyperbolic/, index/, integrity/, learning/, math/, quantization/, routing/, solver/, sona/, sparse/, tda/, tenancy/, types/, workers/
- **rvlite**: Embedded WASM vector DB with SQL + SPARQL (W3C) + Cypher + IndexedDB persistence for browsers
- **ruvector-server**: REST API server for vector databases
- **ruvector-collections**: Multi-collection management with aliases, statistics, DashMap thread-safety
- **ruvector-snapshot**: Backup/restore with compression and checksums

## RVF (19 sub-crates)
rvf-types (segment headers, enums), rvf-wire (zero-copy serialization), rvf-crypto (SHA-3, Ed25519), rvf-runtime (RvfStore API, compaction, streaming), rvf-kernel (Linux microkernel builder), rvf-wasm, rvf-node, rvf-cli, rvf-adapters (AgentDB, SONA, OSpipe, RVLite, claude-flow, agentic-flow), rvf-ebpf (kernel-level vector distance), rvf-federation (PII stripping, differential privacy, federated averaging), rvf-import (JSON, CSV, NumPy), rvf-index (progressive HNSW Layer A/B/C), rvf-launch (QEMU microVM), rvf-manifest (two-level segment tracking), rvf-quant (temperature-tiered f32/f16/u8/binary), rvf-server (TCP/HTTP streaming), rvf-solver-wasm

## Examples
examples/rvf, examples/rvf-desktop (Causal Atlas native app), examples/rvf-kernel-optimized (Linux kernel embedding + formal proofs)

*Source: ruvector/crates/ruvector-postgres/src/lib.rs, ruvector/crates/rvlite/src/lib.rs*
