# Attention Mechanisms — Deep Dive

## Crates
- **ruvector-attention**: 18+ variants, 16 modules
- **ruvector-attention-wasm**, **ruvector-attention-unified-wasm**: Browser
- **ruvector-attention-node**: Node.js NAPI
- **ruvector-attention-cli**: CLI + HTTP server
- **ruvector-attn-mincut**: Dinic's max-flow graph gating
- **ruvector-mincut-gated-transformer** + wasm: KV cache, SQUAT, kernel fusion
- **ruvector-fpga-transformer** + wasm: FPGA hardware, INT4/INT8, deterministic latency

## 16 Deep Modules
| Module | What It Does | Key Algorithm |
|--------|-------------|---------------|
| attention/ | Core multi-head + FlashAttention-3 | O(n) memory tiled attention |
| curvature/ | Mixed geometry E^e × H^h × S^s | Tangent space mapping, fused dot kernel |
| graph/ | GAT-style on graph structure | Adjacency-weighted attention |
| hyperbolic/ | Poincaré ball | Möbius operations |
| info_bottleneck/ | Variational IB | KL divergence regularization |
| info_geometry/ | Fisher metric + natural gradient | K-FAC, conjugate gradient (3-5x fewer iterations) |
| moe/ | Mixture of Experts | Memory-aware routing, EMA affinity (ADR-092) |
| pde_attention/ | Continuous-time PDE | Heat equation on graph Laplacian L=D-W |
| sdk/ | High-level composition API | — |
| sheaf/ | Coherence-Gated Transformer (ADR-015) | Restriction maps, residual energy, energy-based exit |
| sparse/ | Efficient sparse patterns | — |
| topology/ | 3-mode policy gating | stable/cautious/freeze, amortized updates |
| training/ | Training utilities | — |
| transport/ | Optimal Transport attention | Sliced Wasserstein, Centroid OT, histogram CDF |
| unified_report/ | Cross-variant benchmarking | Kruskal MST |

## Selection Guide
Long sequences → FlashAttention-3. Very long (>100K) → Mamba S5. Expert routing → MoE. Coherence → Sheaf. PDE → continuous dynamics. Transport → distribution matching. Hierarchy → Hyperbolic. Graph → GAT. Energy-efficient → Spiking. Hardware → FPGA Transformer. Min-cut → attn-mincut.

*Source: ruvector/crates/ruvector-attention/src/lib.rs*
