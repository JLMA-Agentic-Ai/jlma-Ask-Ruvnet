# Self-Learning — Deep Dive

## Crates
- **sona**: Core adaptive learning engine
- **ruvector-learning-wasm**: MicroLoRA for edge (<100μs)
- **ruvector-domain-expansion** + wasm: Cross-domain transfer learning
- **ruvector-nervous-system** plasticity/: Bio-inspired learning rules

## SONA Three Learning Loops
| Loop | Frequency | Mechanism | Latency |
|------|-----------|-----------|---------|
| A (Instant) | Per-request | MicroLoRA rank-1/2 | <1ms |
| B (Background) | Hourly | Base LoRA + pattern clustering | seconds |
| C (Deep) | Weekly | EWC++ consolidation | minutes |

## SONA Modules
- engine.rs: SonaEngine — begin_trajectory(), end_trajectory(), apply_micro_lora()
- lora.rs: MicroLoRA (rank-2, <1MB) and Base LoRA
- ewc.rs: EWC++ — prevents catastrophic forgetting (45% better)
- reasoning_bank.rs: HNSW-indexed pattern store (150x faster), trajectory recording, verdict analysis, memory consolidation/distillation
- trajectory.rs: Execution path recording with quality metrics
- loops/: instant.rs, background.rs, coordinator.rs
- training/: Templates (code-agent, research, customer-support), Agent Factory, federated learning
- export/: HuggingFace SafeTensors, JSONL dataset, DPO/RLHF preference pairs, distillation targets

## Domain Expansion
Meta Thompson Sampling with Beta priors. Domains: Rust synthesis, planning, tool orchestration. Transfer via dampened priors. Population-based policy search. Acceptance: must improve target without regressing source.

## Bio-Inspired Learning (nervous-system/plasticity)
- BTSP: One-shot learning from single exposure
- EWC: Continual learning without forgetting
- E-prop: Online learning in spiking networks

## Examples
- examples/train-discoveries: Cross-domain ETL with sublinear solver
- examples/ruvLLM: Self-learning LLM with SONA integration

*Source: ruvector/crates/sona/src/lib.rs*
