# OSpipe — ScreenPipe Integration Deep Dive

## Location
examples/OSpipe (31 source files, complete application)

## Components
| Component | Module | What It Does |
|-----------|--------|-------------|
| SafetyGate | safety/gate.rs | PII redaction before storage |
| FrameDeduplicator | pipeline/dedup.rs | Cosine similarity window (threshold 0.95) |
| HnswVectorStore | storage/vector_store.rs | HNSW config: M=16, ef_construction=200, ef_search=40 |
| QueryRouter | search/router.rs | 5 modes: semantic, keyword, graph, temporal, hybrid |
| AttentionReranker | search/reranker.rs | Scaled dot-product, 60% attention + 40% cosine blend |
| MmrReranker | search/mmr.rs | Maximal Marginal Relevance, λ=0.7 |
| QuantumSearch | quantum/mod.rs | QAOA MaxCut diversity selection (threshold=8) |
| SearchLearner | learning/mod.rs | EWC++ continual learning (λ=100.0) |
| EmbeddingQuantizer | learning/mod.rs | Age-based: f32 (<1h) → f16 (1-24h) → PQ8 (1-7d) → binary (>7d) |
| EntityExtractor | graph/entity_extractor.rs | Graph entity extraction |
| EnhancedSearch | search/enhanced.rs | Advanced search features |

## API
- POST /v2/search — Vector search with routing
- POST /v2/route — Explicit query routing
- GET /v2/stats — Collection statistics
- GET /v2/health — Health check

## npm packages
@ruvector/ospipe, @ruvector/ospipe-wasm

## WASM bindings
src/wasm/bindings.rs, src/wasm/helpers.rs

*Source: ruvector/examples/OSpipe/src/lib.rs*
