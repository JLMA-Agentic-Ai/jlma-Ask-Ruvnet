# Dynamic Min-Cut — Deep Dive

## Crates
- **ruvector-mincut** + wasm + node + brain-node: 45,911 LOC — largest crate in RuVector

## Properties
Subpolynomial O(n^0.12) amortized. Deterministic. Exact. Dynamic (handles insertions/deletions). 256-core parallel.

## 22 Source Modules
algorithm/, canonical/ (3 sub: source_anchored, tree_packing, dynamic), certificate/, cluster/, compact/, connectivity/, core/, euler/, expander/, fragment/, fragmentation/, graph/, instance/, integration/, jtree/, linkcut/, localkcut/, monitoring/, optimization/, parallel/, pool/, snn/, sparsify/, subpolynomial/, tree/, wasm/, witness/, wrapper/

## Named Algorithms
Gomory-Hu trees (all-pairs via n-1 max-flow), expander decomposition (approximate via expansion), j-tree hierarchical decomposition (subpolynomial updates), Link-Cut trees (O(log n) dynamic path queries), Karger's randomized min-cut, Stoer-Wagner deterministic, Dinic's max-flow (via ruvector-attn-mincut), Euler tour trees

## Feature Flags
`exact`, `approximate` (1+ε), `jtree`, `tiered` (j-tree + exact two-tier), `canonical` (3 tiers: source_anchored + tree_packing + dynamic), `agentic` (256-core parallel chip backend), `all-cut-queries` (sparsest cut, multiway, multicut), `integration` (GraphDB), `monitoring` (real-time callbacks)

## Use Cases
Find: bottlenecks, weak points, attack surfaces, community boundaries, module boundaries, knowledge gaps. Real-time graph health monitoring. SNN integration for bio-inspired cuts.

## Research
docs/research/mincut (3 docs): LocalKCut algorithm documentation

## Examples
examples/mincut: Exotic — temporal attractors, strange loops, causal discovery

*Source: ruvector/crates/ruvector-mincut/src/lib.rs*
