#!/bin/bash
# ============================================================================
# RuVector Reference Regeneration Script
# ============================================================================
# Run this when the ruvector submodule is updated to a new version.
# It performs the exact same analysis that produced the current inventory,
# ensuring nothing is missed as new features emerge.
#
# Usage:
#   cd <project-root>
#   bash docs/ruvector-reference/regenerate.sh
#
# What it does:
#   1. Verifies ruvector submodule is present and gets version info
#   2. Catalogs every crate, example, npm package, ADR, and doc directory
#   3. Outputs a completeness report showing what's new vs current inventory
#   4. Tells you exactly what Claude Code agents to spawn for the deep scan
#
# This script does NOT write the inventory — it produces the input data
# that a Claude Code session uses to write/update INVENTORY.md and catalog.json.
# ============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
RV_DIR="$PROJECT_ROOT/ruvector"
REF_DIR="$SCRIPT_DIR"

if [ ! -d "$RV_DIR/crates" ]; then
    echo "ERROR: ruvector submodule not found at $RV_DIR"
    echo "Run: git submodule update --init --recursive"
    exit 1
fi

echo "============================================"
echo "RuVector Reference Regeneration"
echo "============================================"
echo ""

# Step 1: Version info
cd "$RV_DIR"
RV_TAG=$(git describe --tags 2>/dev/null || echo "untagged")
RV_COMMIT=$(git rev-parse --short HEAD)
RV_COMMIT_FULL=$(git rev-parse HEAD)
RV_DATE=$(git log -1 --format=%ci)

echo "RuVector Version: $RV_TAG"
echo "Commit: $RV_COMMIT ($RV_DATE)"
echo ""

# Check if version changed from current
if [ -f "$REF_DIR/VERSION" ]; then
    CURRENT_COMMIT=$(python3 -c "import json; print(json.load(open('$REF_DIR/VERSION')).get('ruvector_commit_short',''))" 2>/dev/null || echo "unknown")
    if [ "$CURRENT_COMMIT" = "$RV_COMMIT" ]; then
        echo "WARNING: RuVector commit has NOT changed ($RV_COMMIT)"
        echo "The inventory is already up to date for this version."
        echo "Run 'cd ruvector && git pull' first to get new changes."
        echo ""
    else
        echo "NEW VERSION DETECTED: $CURRENT_COMMIT -> $RV_COMMIT"
        echo ""
    fi
fi

# Step 2: Catalog everything
echo "=== SCOPE ==="
RUST_LINES=$(find . -name "*.rs" -not -path "*/target/*" -exec cat {} + 2>/dev/null | wc -l | tr -d ' ')
SOURCE_FILES=$(find . -name "*.rs" -not -path "*/target/*" | wc -l | tr -d ' ')
CRATE_COUNT=$(ls crates/ | wc -l | tr -d ' ')
EXAMPLE_COUNT=$(ls examples/ | wc -l | tr -d ' ')
NPM_COUNT=$(ls npm/packages/ | wc -l | tr -d ' ')
ADR_COUNT=$(ls docs/adr/*.md 2>/dev/null | wc -l | tr -d ' ')
DOC_DIR_COUNT=$(ls docs/ | wc -l | tr -d ' ')

echo "  Rust lines:      $RUST_LINES"
echo "  Source files:     $SOURCE_FILES"
echo "  Crates:           $CRATE_COUNT"
echo "  Examples:         $EXAMPLE_COUNT"
echo "  npm packages:     $NPM_COUNT"
echo "  ADR files:        $ADR_COUNT"
echo "  Doc directories:  $DOC_DIR_COUNT"
echo ""

# Step 3: Find NEW things not in current inventory
echo "=== NEW CRATES (not in current inventory) ==="
for d in crates/*/; do
    name=$(basename "$d")
    if ! grep -q "$name" "$REF_DIR/INVENTORY.md" 2>/dev/null; then
        desc=$(grep -m1 'description' "$d/Cargo.toml" 2>/dev/null | sed 's/.*= *"//' | sed 's/".*//')
        echo "  NEW: $name — $desc"
    fi
done

echo ""
echo "=== NEW EXAMPLES ==="
for d in examples/*/; do
    name=$(basename "$d")
    if ! grep -qi "$name" "$REF_DIR/INVENTORY.md" 2>/dev/null; then
        echo "  NEW: $name"
    fi
done

echo ""
echo "=== NEW NPM PACKAGES ==="
for d in npm/packages/*/; do
    name=$(basename "$d")
    if ! grep -q "$name" "$REF_DIR/INVENTORY.md" 2>/dev/null; then
        echo "  NEW: $name"
    fi
done

echo ""
echo "=== NEW ADRs ==="
for f in docs/adr/ADR-*.md; do
    num=$(basename "$f" .md)
    if ! grep -q "$num" "$REF_DIR/INVENTORY.md" 2>/dev/null; then
        title=$(head -5 "$f" | grep -m1 '#' | sed 's/^#* *//')
        echo "  NEW: $num — $title"
    fi
done

echo ""
echo "=== EVERY CRATE WITH DESCRIPTION ==="
for d in crates/*/; do
    name=$(basename "$d")
    desc=$(grep -m1 'description' "$d/Cargo.toml" 2>/dev/null | sed 's/.*= *"//' | sed 's/".*//')
    echo "  $name|$desc"
done | sort

echo ""
echo "============================================"
echo "REGENERATION INSTRUCTIONS"
echo "============================================"
echo ""
echo "If NEW items were found above, start a Claude Code session and run:"
echo ""
echo "  1. Read the current inventory:"
echo "     Read docs/ruvector-reference/INVENTORY.md"
echo ""
echo "  2. For each NEW crate, read its source:"
echo "     Read ruvector/crates/<new-crate>/Cargo.toml"
echo "     Read ruvector/crates/<new-crate>/src/lib.rs"
echo ""
echo "  3. Add entries to INVENTORY.md and catalog.json"
echo ""
echo "  4. Update VERSION with new commit hash and date"
echo ""
echo "  For a FULL re-scan (recommended for major version bumps),"
echo "  spawn these 5 parallel agents:"
echo ""
echo "  Agent 1: Explore crates 1-30 (alphabetical)"
echo "  Agent 2: Explore crates 31-60"
echo "  Agent 3: Explore crates 61-90"
echo "  Agent 4: Explore crates 91-114 + sona + ruvllm + rvf + thermorust"
echo "  Agent 5: Explore examples/ + docs/ + npm/ + scripts/"
echo ""
echo "  Each agent prompt:"
echo '  "VERY THOROUGH exploration of ruvector/crates/ (range X-Y).'
echo '   For EACH crate: read Cargo.toml, read every .rs file in src/,'
echo '   list every public struct/trait/enum/function, identify algorithms,'
echo '   note design constants. Return complete findings."'
echo ""
echo "============================================"
echo "Done. Review output above for anything new."
echo "============================================"
