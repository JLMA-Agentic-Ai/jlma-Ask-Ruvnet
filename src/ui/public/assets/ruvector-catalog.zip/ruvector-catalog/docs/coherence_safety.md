# Coherence & Safety — Deep Dive

## Crates
- **prime-radiant**: Universal coherence engine (sheaf Laplacian, governance, substrate, tiles, neural gate, learned rho, cohomology, signal)
- **cognitum-gate-kernel**: 64KB per-tile WASM kernel (256-tile fabric)
- **cognitum-gate-tilezero**: Central arbiter, supergraph merging, permit tokens
- **ruvector-coherence**: Spectral health monitoring (Fiedler, effective resistance)
- **ruvector-cognitive-container**: Sealed WASM container with witness chains
- **mcp-gate**: MCP server for the Coherence Gate
- **ruvector-verified** + wasm: SAT/SMT, bounded model checking, K-induction

## Prime Radiant Modules
| Module | Purpose |
|--------|---------|
| cohomology/ | Sheaf cohomology H^0 (global sections), H^1 (obstructions), sheaf Laplacian L_F |
| governance/ | Immutable witness chains (Blake3), policy bundles, multi-party approval, lineage records |
| substrate/ | Sheaf graph data structures: SheafNode (stalks), SheafEdge (restriction maps), residual energy |
| tiles/ | 256-tile WASM fabric adapter, CoherenceFabric, TileAdapter, FabricReport |
| learned_rho/ | GNN-based restriction map learning from data, EWC, replay buffer, LR scheduling |
| neural_gate/ | Bio-inspired gating: dendritic coincidence, hysteresis, global workspace, HDC encoding, Kuramoto |
| signal/ | Raw signal validation and normalization |
| mincut/ | Min-cut adapter for coherence computation |
| security/ | Security primitives |

## Cognitum Gate
- **Kernel** (64KB per tile): CompactGraph (~42KB), EvidenceAccumulator (~2KB), TileState (~1KB). WASM exports: ingest_delta, tick, get_witness_fragment
- **TileZero** (arbiter): Merges worker reports into supergraph. Three-filter decision (structural + evidence + decision). Crypto-signed permit tokens. Hash-chained witness receipt log

## Coherence Metrics
contradiction_rate, entailment_consistency, delta_behavior, cosine_similarity, l2_distance. Spectral: Fiedler value, effective resistance, degree regularity, HNSW health monitoring.

## Verified Applications (examples/verified-applications)
10 applications: weapons filters, legal forensics, financial compliance, medical diagnosis, autonomous vehicles, nuclear safety, aviation control, pharmaceutical, critical infrastructure, election systems.

*Source: ruvector/crates/prime-radiant/src/lib.rs*
