# Graph Intelligence — Deep Dive

## Crates
- **ruvector-graph** + wasm + node: Neo4j-compatible hypergraph, Cypher, 230+ SQL functions. Modules: cypher/ (Pest+LALRPOP parsers), distributed/ (Raft+sharding), executor/, hybrid/, optimization/
- **rvlite**: Embedded WASM vector DB with SQL + SPARQL + Cypher + IndexedDB. Modules: cypher/, sparql/, sql/, storage/
- **ruvector-gnn** + wasm + node: GCN, GAT, GraphSAGE on HNSW topology. Features: mmap (large graphs), cold-tier (hyperbatch), napi
- **ruvector-graph-transformer** + wasm + node: 8-module proof-gated transformer (physics, biological, manifold, Boltzmann)
- **ruvector-dag** + wasm: DAG for query optimization. Modules: dag/, attention/, healing/, mincut/, qudag/ (quantum-resistant), sona/
- **ruvector-sparsifier** + wasm: Spectral graph sparsification preserving Laplacian properties

## Graph Algorithms Available
PageRank, Louvain community detection, EigenTrust, BFS, DFS, Dijkstra, Kruskal MST, connected components, shortest path, betweenness centrality

## Feature Flags (ruvector-graph)
`full`, `distributed` (Raft+cluster+replication), `federation` (gRPC multi-cluster), `compression` (zstd+lz4), `fulltext`, `geospatial`, `temporal`, `cypher-pest`, `cypher-lalrpop`

## QuDAG (inside ruvector-dag)
Quantum-Resistant Distributed Pattern Learning: ML-DSA-65 (Dilithium3), ML-KEM-768 (Kyber768), differential privacy. Governance tokens, staking, rewards.

## Examples
examples/graph, examples/delta-behavior, examples/prime-radiant

*Source: ruvector/crates/ruvector-graph/src/lib.rs*
