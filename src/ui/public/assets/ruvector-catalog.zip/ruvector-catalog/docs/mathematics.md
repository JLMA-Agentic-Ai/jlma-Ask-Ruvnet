# Mathematics — Deep Dive

## Crates
- **ruvector-math** + wasm: 10 modules of advanced math
- **ruvector-solver** + wasm + node: 8 sublinear algorithms + auto-router
- **ruvector-mincut** + wasm + node + brain-node: 45,911 LOC, subpolynomial dynamic min-cut
- **ruvector-sparsifier** + wasm: Spectral graph sparsification
- **ruvector-dither**: Golden ratio + π pre-quantization dithering

## ruvector-math Modules
| Module | What It Does | Key Algorithms |
|--------|-------------|----------------|
| optimal_transport/ | Distribution comparison | Sliced Wasserstein O(n log n), Sinkhorn (log-stabilized), Gromov-Wasserstein (cross-space) |
| tropical/ | Max-plus semiring | Neural network linear region counting, tropical eigenvalues, Floyd-Warshall via tropical matrix |
| homology/ | Topological Data Analysis | Persistent homology, Betti numbers, persistence diagrams, bottleneck/Wasserstein distance |
| information_geometry/ | Probability manifold optimization | Fisher Information Matrix, K-FAC, natural gradient (3-5x fewer iterations than Adam/SGD) |
| product_manifold/ | Mixed-curvature geometry | H^h × E^e × S^s spaces (20x memory reduction on taxonomy data) |
| tensor_networks/ | High-dimensional compression | Tensor Train, Tucker, CP decomposition, network contraction |
| spherical/ | Spherical operations | Stereographic projection, spherical harmonics |
| spectral/ | Eigenvalue methods | Chebyshev polynomials, Lanczos eigenvalue computation, power iteration |
| utils/ | Shared utilities | — |

## ruvector-solver (8 algorithms)
| Algorithm | Complexity | Use When |
|-----------|-----------|----------|
| Neumann Series | O(k * nnz) | Diag-dominant, spectral radius < 1 |
| Conjugate Gradient | O(√κ * log(1/ε)) | Symmetric positive-definite |
| Forward Push | O(1/ε) | Single-source PageRank |
| Backward Push | O(1/ε) | Reverse PageRank |
| Hybrid Random Walk | Sublinear | Large-scale pairwise PageRank |
| BMSSP Multigrid | O(nnz * log n) | Laplacian/SPD multi-scale |
| TRUE Solver | O(log n) | Batch via JL projection |
| Auto-Router | Varies | Don't know which to use |

Additional: Jacobi iteration, Gauss-Seidel, PCG32 PRNG, Johnson-Lindenstrauss, Welford's online variance, power iteration, dense Gaussian elimination fallback.

## ruvector-mincut (largest crate, 45,911 LOC)
Subpolynomial O(n^0.12) dynamic updates. Canonical 3-tier: source-anchored, tree packing, dynamic. Gomory-Hu trees, expander decomposition, j-tree hierarchical, Link-Cut trees O(log n), Karger randomized, Stoer-Wagner deterministic. 256-core parallel. SNN integration. Euler tour trees.

Feature flags: `exact`, `approximate`, `jtree`, `tiered`, `canonical`, `agentic` (256-core), `all-cut-queries`, `integration`, `monitoring`

## Examples
- examples/subpolynomial-time: Demo of dynamic min-cut
- examples/mincut: Exotic — temporal attractors, strange loops, causal discovery

*Source: ruvector/crates/ruvector-math/src/lib.rs, ruvector/crates/ruvector-solver/src/lib.rs, ruvector/crates/ruvector-mincut/src/lib.rs*
