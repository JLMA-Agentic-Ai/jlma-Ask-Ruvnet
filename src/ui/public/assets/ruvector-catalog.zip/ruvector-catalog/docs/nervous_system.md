# Bio-Inspired Nervous System — Deep Dive

## Crates
- **ruvector-nervous-system** + wasm: 5-layer architecture

## 5 Layers: Sensing → Reflex → Memory → Learning → Coherence

## 9 Deep Modules
| Module | What It Implements | Performance |
|--------|-------------------|-------------|
| hopfield/ | Modern Hopfield Networks (Ramsauer 2020). Exponential storage 2^(d/2). Softmax-weighted retrieval, β tuning | — |
| hdc/ | Hyperdimensional Computing. 10,000-bit binary hypervectors. SIMD-optimized. bind, bundle, permute, invert | <100ns Hamming |
| dendrite/ | Dendritic coincidence detection. NMDA nonlinearity, compartmental models, plateau potentials (100-500ms), Ca²⁺ dynamics | <10μs/100 synapses |
| plasticity/ | BTSP (one-shot), EWC (continual), E-prop (online spiking) | — |
| compete/ | WTA (single winner, lateral inhibition), K-WTA (sparse distributed coding) | <1μs/1000 neurons (WTA), <10μs (K-WTA k=50) |
| eventbus/ | DVS event stream processing. Lock-free ring buffers, region sharding, backpressure | 10,000+ events/ms |
| routing/ | Oscillatory routing. Kuramoto oscillators (40Hz gamma sync). Global Workspace (4-7 item capacity, Baars 1988) | — |
| separate/ | Signal separation and isolation | — |
| integration/ | Cross-module integration | — |

## Key Types
- Hypervector (10,000-bit, 157 u64 words)
- HdcMemory (associative memory store)
- ModernHopfield (network with retrieval)
- Dendrite (NMDA coincidence detector)
- DendriticTree (multi-branch with soma)
- WTALayer, KWTALayer, LateralInhibition
- DVSEvent, EventRingBuffer, ShardedEventBus, BackpressureController

## Use Cases
- Fast HNSW routing via WTA competition
- Pattern matching via HDC (10,000-dim, <100ns)
- Attention head selection via K-WTA
- One-shot learning via BTSP + dendritic computation
- Noise filtering via dendritic coincidence detection
- Event-driven processing via DVS eventbus

## Examples
- examples/spiking-network: ASIC-optimized neuromorphic computing
- examples/meta-cognition-spiking-neural-network: Meta-cognitive SNN

*Source: ruvector/crates/ruvector-nervous-system/src/lib.rs*
