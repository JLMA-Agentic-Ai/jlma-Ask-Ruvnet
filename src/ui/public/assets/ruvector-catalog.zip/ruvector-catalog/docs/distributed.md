# Distributed Systems — Deep Dive

## Crates
- **ruvector-raft**: Raft consensus — leader election, log replication, snapshots, AppendEntries/RequestVote/InstallSnapshot RPCs
- **ruvector-cluster**: Consistent hashing (150 virtual nodes), DAG consensus, gossip discovery, static discovery, shard routing
- **ruvector-replication**: Multi-node with vector clocks, CRDTs, sync/async/semi-sync modes, change data capture, automatic failover, split-brain prevention
- **ruvector-delta-core**: Behavioral vector change tracking, delta streams, windowed aggregation, sparse/dense encoding, compression
- **ruvector-delta-consensus**: CRDT merging with hybrid logical clocks, vector clocks, causal ordering, conflict resolution
- **ruvector-delta-graph**: Incremental graph edge/node updates with delta-aware traversal
- **ruvector-delta-index**: Delta-aware HNSW with automatic repair strategies and recall monitoring
- **ruvector-delta-wasm**: WASM bindings for all delta operations
- **ruvector-economy-wasm**: CRDT credit economy (G-Counter, PN-Counter), stake/slash, 10x early-adopter multiplier, reputation scoring (accuracy+uptime+stake), Merkle verification
- **ruvector-snapshot**: Point-in-time backup/restore with compression and checksums
- **ruvector-metrics**: Prometheus-compatible (search latency histograms, insert counters, memory gauges, health checks, readiness probes)

## Examples
examples/edge-net: Distributed compute network, earn credits
examples/edge, examples/edge-full: Edge deployment

*Source: ruvector/crates/ruvector-raft/src/lib.rs, ruvector/crates/ruvector-cluster/src/lib.rs*
