# Vector Search — Deep Dive

## Crates
- **ruvector-core**: HNSW (61μs), DiskANN (billion-scale SSD), hybrid (keyword+semantic RRF, 20-49% better), ColBERT (per-token), Matryoshka (variable-dim), neural hashing (32x compression)
- **ruvector-hyperbolic-hnsw** + wasm: Poincaré ball for hierarchical data
- **micro-hnsw-wasm**: 11.8KB WASM with spiking neurons for IoT/ASIC
- **ruvector-filter**: Payload filtering (equality, range, geo, text, boolean, AND/OR/NOT)
- **ruvector-collections**: Multi-collection management with aliases
- **ruvector-node**: Node.js NAPI bindings

## Feature Flags (ruvector-core)
| Flag | Enables | When |
|------|---------|------|
| `simd` | AVX2/SSE4/NEON | Native builds |
| `parallel` | Rayon + crossbeam | Server builds |
| `storage` | redb + memmap2 persistence | Data must survive restart |
| `hnsw` | HNSW indexing | Default — almost always |
| `memory-only` | No file I/O | WASM builds |
| `api-embeddings` | HTTP providers (reqwest) | Cloud embedding |
| `onnx-embeddings` | Local ONNX (ort + tokenizers) | On-device embedding |

## Key Types
VectorDB, VectorEntry, SearchQuery, HnswConfig, DistanceMetric (Cosine/Euclidean/DotProduct/Manhattan), DbOptions

## Quantization
Binary (1-bit, 32x compression), Product Quantization (codebook), Int8, Temperature-tiered via RVF (f32→f16→u8→binary as data ages)

## Examples
- examples/onnx-embeddings — Local ONNX embedding pipeline
- examples/onnx-embeddings-wasm — Browser WASM with SIMD
- examples/wasm, wasm-react, wasm-vanilla — Browser integration

*Source: ruvector/crates/ruvector-core/src/lib.rs*
