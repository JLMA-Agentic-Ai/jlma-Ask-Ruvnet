# LLM Runtime — Deep Dive

## Crates
- **ruvllm** + **ruvllm-cli** + **ruvllm-wasm**: Full inference engine

## Modules (21 inside ruvllm/src/)
| Module | What It Does |
|--------|-------------|
| bitnet/ | BitNet b1.58 ternary {-1,0,+1} quantization, multiplication-free inference |
| qat/ | Quantization-Aware Training: STE variants, calibration, knowledge distillation, reasoning loss, LoRA-QAT |
| moe/ | Memory-aware expert routing with EMA affinity (ADR-092), <10μs target, cache residency bonus |
| lora/ | MicroLoRA per-request adaptation <1MB, rank-2 |
| metal/ | Apple Silicon M4: Flash Attention, GEMM (simdgroup_half8x8), RMSNorm, LayerNorm, RoPE |
| serving/ | Continuous batching: prefill/decode scheduling, preemption, request queuing |
| reasoning_bank/ | Learn from Claude/LLM trajectories, HNSW-indexed pattern search |
| reflection/ | ReflectiveAgent, IoE confidence, multi-perspective critique, error pattern learning |
| backends/ | Provider abstraction layer |
| gguf/ | GGUF model loading with mmap |
| context/ | KV cache management, paged attention, prefix sharing |
| hub/ | Model download and management |
| intelligence/ | Intelligence metrics and evaluation |
| kernels/ | Compute kernels |
| models/ | Model architecture definitions |
| optimization/ | Performance tuning |
| quality/ | Output quality assessment |
| quantize/ | Weight quantization |
| sona/ | SONA learning integration |
| training/ | Training utilities |
| claude_flow/ | Claude Flow integration |

## Feature Flags
`candle`, `metal`, `metal-compute`, `cuda`, `inference-metal`, `inference-metal-native`, `inference-cuda`, `mmap`/`gguf-mmap`, `coreml`, `hybrid-ane` (Apple Neural Engine), `ruvector-full`, `quantize`

## Examples
examples/ruvLLM: Self-learning LLM with LFM2 + NEON/Metal

*Source: ruvector/crates/ruvllm/src/lib.rs*
